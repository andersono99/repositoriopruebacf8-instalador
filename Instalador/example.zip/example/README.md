# AppFactory generated micro-service : PsecomcolBaasAch application.
Project includes chassis libraries with boiler plate features such as :
Logging,
Metrics,
Health,
Security,
Tracing,
Masking,
SOAP Connector,
REST Connector,
Gradle Plugin,
Caching

When using AppFactory UI with security enabled and OAuth2Client selected, Appfactory generates ChassisRolesProvider bean by default and adds to it all the roles present
in the OpenAPI input spec to all the authenticated users.
You will have to add custom logic to map specific roles to specific users and restrict access to your endpoints to users with specific roles.
