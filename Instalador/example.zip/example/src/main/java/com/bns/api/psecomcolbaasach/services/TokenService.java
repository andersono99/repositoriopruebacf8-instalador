package com.bns.api.psecomcolbaasach.services;

import com.bns.api.psecomcolbaasach.model.consumer.rest.TokenResponses;
import com.bns.chassis.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;

@Service
public class TokenService {
    @Value("${security.resource.uri}")
    private String tokenService;

    private HttpHeaders headers;

    private RestTemplate restTemplate;

    private static final String GRANT_TYPE = "grant_type";
    private static final String CLIENT_ID = "client_id";
    private static final String CLIENT_SECRET = "client_secret";

    private static final Logger LOG = Logger.get(TokenService.class);

    public TokenService() {
        restTemplate = new RestTemplate();

        InetSocketAddress isa2 = new InetSocketAddress("localhost", 5050);

        headers = new HttpHeaders();
        headers.setContentType(MediaType.valueOf(MediaType.APPLICATION_FORM_URLENCODED_VALUE));
        headers.setContentLength(571);
        headers.setHost(isa2);
    }

    public TokenResponses getToken(String grant_type, String client_id, String client_secret) {
        LOG.info("Entered TokenService. In get token with specific scopes method");
        MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();
        payload.add(GRANT_TYPE, grant_type);
        payload.add(CLIENT_ID, client_id);
        payload.add(CLIENT_SECRET, client_secret);



        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(payload, headers);

        MultiValueMap<String, String> queryparams = new LinkedMultiValueMap<>();
        queryparams.add("grant_type", "client_credentials");
        //String url = this.tokenService + "?grant_type=client_credentials";
        String url = "https://apicer.pse.com.co/oauth/client_credential/accesstoken?grant_type=client_credentials";

        System.out.println(url);
        System.out.println(request);
        return restTemplate.postForObject(url , request, TokenResponses.class);
    }

}
