package com.bns.api.psecomcolbaasach.services;

import com.bns.api.psecomcolbaasach.model.consumer.rest.TokenResponses;
import org.apache.http.NameValuePair;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.cloud.openfeign.FeignClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@FeignClient(url = "${services.baas-billing.url}", name = "billingPlanServiceClient")
public interface TokenServices2 {

    String token = "?grant_type=client_credentials";
    @PostMapping(value = token, consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<TokenResponses> createApprovedBillingPlan (
            @RequestHeader Map<String, Object> headerParams,
            @RequestBody List<NameValuePair> body
    );

}