package com.bns.api.psecomcolbaasach.consumer;

import com.bns.api.psecomcolbaasach.model.consumer.rest.BanksRequest;
import com.bns.api.psecomcolbaasach.model.consumer.rest.TransactionFinalizeRequest;
import com.bns.api.psecomcolbaasach.model.consumer.rest.TransactionInformationRequest;
import com.bns.api.psecomcolbaasach.model.consumer.rest.TransactionRequest;
import com.bns.chassis.lifecycle.model.RestConsumerRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@javax.annotation.Generated(value = "1.6.0", date = "2022-05-27T20:27:24.213Z")

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AchControllerTest {

    @Autowired
    private WebApplicationContext context;

    @MockBean
    private AchRequestDelegate achRequestDelegate;

    @Mock
    RestConsumerRequest request;

    @Mock
    ResponseEntity response;

    @Autowired
    private ObjectMapper objectMapper;

    private MockMvc mvc;

    @Before
    public void setup() {
        mvc = MockMvcBuilders
                .webAppContextSetup(context)
                .alwaysDo(print())
                .build();
        MockitoAnnotations.initMocks(this);
    }

    //TODO: support @Requestparameter

    @Test
    @WithMockUser(roles = {
            "psecomcol:baas:ach:write"

    })
    public void createTransactionPaymentNFTest() throws Exception {
        Mockito.lenient().when(achRequestDelegate.createTransactionPaymentNF(request)).thenReturn(response);
        MockHttpServletRequestBuilder requestBuilder = request(HttpMethod.POST, "/api/v1/ach/transaction-create").content(objectMapper.writeValueAsString(TransactionRequest.buildExample())).contentType("application/json");
        mvc.perform(requestBuilder
                .header("x-b3-traceid", "xB3Traceid_example")
                .header("x-b3-spanid", "xB3Spanid_example")
                .header("x-channel-id", "ENUM")
                .header("x-originating-appl-code", "xOriginatingApplCode_example")
                .header("x-country-code", "xCountryCode_example")
                .header("x-user-context", "xUserContext_example")
        ).andExpect(status().is2xxSuccessful());
    }

    @Test
    @WithMockUser(roles = {
            "psecomcol:baas:ach:write"

    })
    public void finalizeTransactionTest() throws Exception {
        Mockito.lenient().when(achRequestDelegate.finalizeTransaction(request)).thenReturn(response);
        MockHttpServletRequestBuilder requestBuilder = request(HttpMethod.POST, "/api/v1/ach/transaction-finalize").content(objectMapper.writeValueAsString(TransactionFinalizeRequest.buildExample())).contentType("application/json");
        mvc.perform(requestBuilder
                .header("x-b3-traceid", "xB3Traceid_example")
                .header("x-b3-spanid", "xB3Spanid_example")
                .header("x-channel-id", "ENUM")
                .header("x-originating-appl-code", "xOriginatingApplCode_example")
                .header("x-country-code", "xCountryCode_example")
                .header("x-user-context", "xUserContext_example")
        ).andExpect(status().is2xxSuccessful());
    }

    @Test
    @WithMockUser(roles = {
            "psecomcol:baas:ach:read"

    })
    public void getBankListAchTest() throws Exception {
        Mockito.lenient().when(achRequestDelegate.getBankListAch(request)).thenReturn(response);
        MockHttpServletRequestBuilder requestBuilder = request(HttpMethod.POST, "/api/v1/ach/banklist").content(objectMapper.writeValueAsString(BanksRequest.buildExample())).contentType("application/json");
        mvc.perform(requestBuilder
                .header("x-b3-traceid", "xB3Traceid_example")
                .header("x-b3-spanid", "xB3Spanid_example")
                .header("x-channel-id", "ENUM")
                .header("x-originating-appl-code", "xOriginatingApplCode_example")
                .header("x-country-code", "xCountryCode_example")
                .header("x-user-context", "xUserContext_example")
        ).andExpect(status().is2xxSuccessful());
    }

    @Test
    @WithMockUser(roles = {
            "psecomcol:baas:ach:write"

    })
    public void getTransactionInformationTest() throws Exception {
        Mockito.lenient().when(achRequestDelegate.getTransactionInformation(request)).thenReturn(response);
        MockHttpServletRequestBuilder requestBuilder = request(HttpMethod.POST, "/api/v1/ach/transaction-info").content(objectMapper.writeValueAsString(TransactionInformationRequest.buildExample())).contentType("application/json");
        mvc.perform(requestBuilder
                .header("x-b3-traceid", "xB3Traceid_example")
                .header("x-b3-spanid", "xB3Spanid_example")
                .header("x-channel-id", "ENUM")
                .header("x-originating-appl-code", "xOriginatingApplCode_example")
                .header("x-country-code", "xCountryCode_example")
                .header("x-user-context", "xUserContext_example")
        ).andExpect(status().is2xxSuccessful());
    }

}
